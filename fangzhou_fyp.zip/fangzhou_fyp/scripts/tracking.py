#!/usr/bin/env python
import cv2
import mediapipe as mp
import numpy as np
import rospy
from std_msgs.msg import Float32MultiArray

mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles
mp_holistic = mp.solutions.holistic



def capture():
    cap = cv2.VideoCapture(0)
    with mp_holistic.Holistic(
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5) as holistic:
        while cap.isOpened():
            success, image = cap.read()
            if not success:
                print("Ignoring empty camera frame.")
                continue

            # To improve performance, optionally mark the image as not writeable to
            # pass by reference.
            image.flags.writeable = False
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            results = holistic.process(image)
            # Draw the pose annotation on the image.
            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            mp_drawing.draw_landmarks(
                image,
                results.pose_landmarks,
                mp_holistic.POSE_CONNECTIONS,
                landmark_drawing_spec=mp_drawing_styles
                    .get_default_pose_landmarks_style())

            coords = np.array(
                [results.pose_landmarks.landmark[mp_holistic.PoseLandmark.RIGHT_SHOULDER],  # right shoulder
                 results.pose_landmarks.landmark[mp_holistic.PoseLandmark.RIGHT_ELBOW],  # right elbow
                 results.pose_landmarks.landmark[mp_holistic.PoseLandmark.RIGHT_WRIST],  # right wrist
                 results.pose_landmarks.landmark[mp_holistic.PoseLandmark.RIGHT_PINKY],  # right pinky knuckle
                 results.pose_landmarks.landmark[mp_holistic.PoseLandmark.RIGHT_INDEX],  # right index knuckle
                 results.pose_landmarks.landmark[mp_holistic.PoseLandmark.RIGHT_THUMB]])  # right thumb knuckle

            def get_x(each):
                return each.x

            def get_y(each):
                return each.y

            def get_z(each):
                return each.z

            points_x = np.array(list(map(get_x, coords)))
            points_y = np.array(list(map(get_y, coords)))
            points_z = np.array(list(map(get_z, coords)))

            points = np.vstack((points_x, points_y, points_z)).T
            
            # Flip the image horizontally for a selfie-view display.
            cv2.imshow('MediaPipe Pose', cv2.flip(image, 1))
            if cv2.waitKey(5) & 0xFF == 27:
                break

            pub = rospy.Publisher('points', Float32MultiArray, queue_size=10)
            rospy.init_node('talker', anonymous=True)
            rate = rospy.Rate(10) # 10hz
            while not rospy.is_shutdown():
                points_arr = Float32MultiArray(coords)
                rospy.loginfo(points_arr)
                pub.publish(points_arr)
                rate.sleep()
            
    cap.release()
    return



if __name__ == '__main__':
    try:
        capture()
    except rospy.ROSInterruptException:
        pass